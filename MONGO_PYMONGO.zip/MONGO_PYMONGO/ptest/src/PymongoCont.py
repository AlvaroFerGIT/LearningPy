'''
Created on 8 nov. 2018

@author: A735851
'''

from pprint import pprint
from pymongo import MongoClient
from pymongo import ReturnDocument
from bson.objectid import ObjectId
from _codecs import register

# INSERT, UPDATE AND DELETE IN PYMONGO
# MANAGEMENT CLASS
class MongoDBManagement:
    # CONSTRUCTOR
    def __init__(self):
        self.client = MongoClient('localhost', 27017)
        self.db = self.client['MyCompany_DB']
        self.collection_employees = self.db['employees']
        self.collection_customers = self.db['customers']
    # INSERT METHOD
    def insert(self,option,dictionary):
        if 1 == option:
            self.collection_employees.insert_one(dictionary)
        if 2 == option:
            self.collection_customers.insert_one(dictionary)
    # SEARCHES AND RETURNS REGISTERS OF EMPLOYEES
    def return_employees(self, name):
        return self.collection_employees.find({'name': name})
    # SEARCHES AND RETURNS REGISTERS OF CUSTOMERS
    def return_customers(self, name):
        return self.collection_customers.find({'company': name})