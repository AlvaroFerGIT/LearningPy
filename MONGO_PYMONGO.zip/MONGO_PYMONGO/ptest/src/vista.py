'''
Created on 8 nov. 2018

@author: A735851
''' 

#STARTS THE MENU
def start():
    print("1 - CREATE NEW EMPLOYEE, "
     + " 2 - CREATE NEW CUSTOMER, "
     + " 3 - SEARCH EMPLOYEE BY NAME, "
     + " 4 - SEARCH CUSTOMER BY NAME")
# ASKS FOR OPTION
def giveoption():
    option = int(input("Choose an option: "))
    return option
# CONFIRMS THAT EMPLOYEE HAS BEEN REGISTERED SUCCESSFULLY
def confirm_employee():
    print("Employee registered successfully.")
# CONFIRMS THAT CUSTOMER HAS BEEN REGISTERED SUCCESSFULLY
def confirm_customer():
    print("Customer registered successfully.")
# SEARCHS EMPLOYEES BY THEIR NAME
def search_employee_by_name():
    return input("Search name of employee: ")
# PRINTS A LIST OF EVERY REGISTER FOUND THAT EQUALS TO THE NAME SEARCHED
def showRegister(list_register):
    for item in list_register:
        print(item)
# SEARCHS BY COMPANY'S NAME OF A CUSTOMER
def search_customer_by_name():
    return input("Search company by name: ")