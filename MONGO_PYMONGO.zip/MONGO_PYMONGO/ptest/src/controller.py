'''
Created on 8 nov. 2018

@author: A735851
'''

# BUILDS A DICTIONARY OF EMPLOYEE DATA AND RETURNS IT
def dictionary_employee_construction():
    dictionary = {}
    name = input("Employee name: ")
    dictionary["name"] = name
    surname = input("Employee surname: ")
    dictionary["surname"] = surname
    age = int(input("Employee age: "))
    dictionary["age"] = age
    country = input("Employee country: ") 
    dictionary["country"] = country
    return dictionary
# BUILDS A DICTIONARY OF CUSTOMER DATA AND RETURNS IT
def dictionary_customer_construction():
    dictionary = {}
    company = input("Customer Company name: ")
    dictionary["company"] = company
    area = input("Customer's area: ")
    dictionary["area"] = area
    country = input("Customer's country: ")
    dictionary["country"] = country
    return dictionary
