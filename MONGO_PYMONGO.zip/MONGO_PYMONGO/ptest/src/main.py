'''
Created on 8 nov. 2018

@author: A735851
'''
import vista
import controller
from PymongoCont import MongoDBManagement
# INSTANCE OF PYMON CONTROLLER
mongomanage = MongoDBManagement()
# SHOWS MENU
vista.start()
# GETS OPTION
option = vista.giveoption()
# OPTION MANAGEMENT
if 1 == option:
    employee_dictionary = controller.dictionary_employee_construction()
    mongomanage.insert(option,employee_dictionary)
    vista.confirm_employee()
if 2 == option:
    customer_dictionary = controller.dictionary_customer_construction()
    mongomanage.insert(option,customer_dictionary)
    vista.confirm_customer()
if 3 == option:
    vista.showRegister(mongomanage.return_employees(vista.search_employee_by_name()))
if 4 == option:
    vista.showRegister(mongomanage.return_customers(vista.search_customer_by_name()))