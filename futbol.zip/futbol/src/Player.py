from src.Associated import Associated
class Player(Associated):
    def __init__(self, name, surnames, age, nid, dni, nss, country, position, idpl):
        super().__init__(name, surnames, age, nid, dni, nss)
        self.__name = name
        self.__surnames = surnames
        self.__age = age
        self.__nid = nid
        self.__dni = dni
        self.__nss = nss
        self.__country = country
        self.__position = position
        self.__idplayer = idpl
    # RETURNS GENERAL INFORMATION
    def getInfo(self):
        return super().generalInfo() + "Motherland: "+self.__country+", main position: "+self.__position+", ID"+str(self.__idplayer)
    # TO PRINT
    def showList(self):
        print("Player's name: "+self.__name+", surnames: "+self.__surnames +", age: "+str(self.__age)+", N.I.D.: "+str(self.__nid)+", DNI: "+self.__dni+", NSS: "+self.__nss+", country: "+self.__country+", main position: "+self.__position+", ID: "+str(self.__idplayer)+".")
