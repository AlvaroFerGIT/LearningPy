from Team import Team
from Trainer import Trainer
from Player import Player
from src.Associated import Associated
# VARIABLES $$$$$$$$$$$$$$$$$$$$$$$$$
option = 0
validation = 3
memberList = []
nid = 0
# WELCOME MESSAGE $$$$$$$$$$$$$$$$$$$$$$$$$$$$$
print("Welcome to the new members registration, please choose an action below:")
# LOOP FOR MENU $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
while option != 6:
    # LOOP FOR EXCEPTION IN CASE OPTION ISN'T A NUMBER
    try:
        option = int(input("1 NEW ASSOCIATE, 2 NEW PLAYER, 3 NEW TRAINER, 4 REGISTER A TEAM, 5 SHOW REGISTERS, 6 QUIT: "))
    except ValueError:
        print("Invalid type, please use a number.")
        # OPTION MANAGEMENT $$$$$$$$$$$$$$$$$$$$$$$$$$$$
    # 1 = NEW ASSOCIATED
    if 1 == option:
        while validation != 1 and validation != 0 or option == 1:
            name = input("New Associated Name: ")
            surnames = input("New Associated Surnames: ")
            age = input("New Associated Age (permitted below 18): ")
            dni = input("New Associated DNI: ")
            nss = input("New Associated Number of Social Security: ")
            print("Are these data O.K?: ")
            print(name+","+surnames+","+age+","+dni+","+nss)
            validation = int(input("1 to continue, 2 to re-introduce data."))
            # VALIDATION
            if validation == 1:
                nid = nid+1
                new_member = Associated(name, surnames, age, nid, dni, nss)
                memberList.append(new_member)
                print(new_member.generalInfo())
                print("")
                validation = 0
                option = 0
        # 2 - NEW PLAYER
    if 2 == option:
        while validation != 1 and validation != 0 or option == 2:
            name = input("New Player Name: ")
            surnames = input("New Player Surnames: ")
            age = input("New Player Age (permitted below 18): ")
            dni = input("New Player DNI: ")
            nss = input("New Player Number of Social Security: ")
            country = input("New Player Country: ")
            position = input("New Player Position: ")
            idpl = input("New Player ID Number: ")
            print("Are these data O.K?: ")
            print(name+", "+surnames+", "+age+", "+dni+", "+nss+", "+country+", "+position+", "+idpl)
            validation = int(input("1 to continue, 2 to re-introduce data."))
            # VALIDATION
            if validation == 1:
                nid = nid + 1
                new_member = Player(name, surnames, age, nid, dni, nss, country, position, idpl)
                memberList.append(new_member)
                print(new_member.getInfo(), end=" ")
                print("")
                validation = 0
                option = 0
    if 3 == option:
        while validation != 1 and validation != 0 or option == 3:
            name = input("New Trainer Name: ")
            surnames = input("New Trainer Surnames: ")
            age = input("New Trainer Age (permitted below 18): ")
            dni = input("New Trainer DNI: ")
            nss = input("New Trainer Number of Social Security: ")
            yoe = input("New Trainer years of experience: ")
            idtrainer = input("New Trainer ID Trainer: ")
            print("Are these data O.K?: ")
            print(name+", "+surnames+", "+age+", "+dni+", "+nss+", "+yoe+", "+idtrainer+".")
            validation = int(input("1 to continue, 2 to re-introduce data."))
            # VALIDATION
            if validation == 1:
                nid = nid + 1
                new_member = Trainer(name, surnames, age, nid, dni, nss, yoe, idtrainer)
                memberList.append(new_member)
                print(new_member.getInfo(), end=" ")
                print("")
                validation = 0
                option = 0
    if 4 == option:
        while validation != 1 and validation != 0 or option == 4:
            name = input("Team's name: ")
            trophies = input("Total trophies the team owns: ")
            city = input("Team's city: ")
            tnum = input("Team's ID number: ")
            print("Are these data O.K?: ")
            print(name+", "+trophies+", "+city+", "+tnum+".")
            validation = int(input("1 to continue, 2 to re-introduce data."))
            # VALIDATION
            if validation == 1:
                new_team = Team(name, trophies, city, tnum)
                memberList.append(new_team)
                print(new_team.getInfo(), end=" ")
                print("")
                validation = 0
                option = 0
        # SHOWING ALL REGISTERS MADE WHILE PROGRAM WAS ON
    if 5 == option:
        print("New registers are: ")
        for i in memberList:
            i.showList()
