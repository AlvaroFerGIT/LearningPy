class Team:
# CONSTRUCTOR FOR THE CLASS TEAM
    def __init__(self, name, trophy, city, tnum):
        self.name = name
        self.trophy = trophy
        self.city = city
        self.__tnum = tnum
    # FUNCTION TO GET GENERAL INFO ABOUT THE TEAM.
    def getInfo(self):
        return "Name: " + self.name + ", trophies: " + str(self.trophy) +", city representing: " + self.city + ", Number of Identification: " + str(self.__tnum)
    # TO PRINT
    def showList(self):
        print("Team name: "+self.name+", trophies: "+self.trophy +", city: "+self.city+", identification number: "+self.__tnum+". ")