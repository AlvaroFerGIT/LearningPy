class Federation(object):
    __name = "Futbol Federation S.A."
    __director = "Ahnad Rahshat"
    __subdirector = "Binla Strahd"

    def getInfo(self):
        return self.__name, self.__director, self.__subdirector
