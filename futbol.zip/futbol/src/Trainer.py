from src.Associated import Associated
class Trainer(Associated):
    def __init__(self, name, surnames, age, nid, dni, nss, yoe, idtrainer):
        super().__init__(name, surnames, age, nid, dni, nss)
        self.__name = name
        self.__surnames = surnames
        self.__age = age
        self.__nid = nid
        self.__dni = dni
        self.__nss = nss
        self.yearsofexperience = yoe
        self.idtrainer = idtrainer
    # RETURNS SUPER INFO + TRAINER INFO
    def getInfo(self):
        return super().generalInfo() + " years of experience: "+ self.yearsofexperience +", Trainer ID: "+ self.idtrainer
    # PRINTS ALL ATTRS
    def showList(self):
        print("Trainer's name: "+self.__name+", surnames: "+self.__surnames +", age: "+str(self.__age)+", N.I.D. : "+str(self.__nid)+", DNI: "+self.__dni+", NSS: "+self.__nss+", years of experiencie: "+str(self.yearsofexperience)+", ID: "+self.idtrainer+".")
