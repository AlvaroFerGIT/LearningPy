class Associated:
    def __init__(self, name, surnames, age, nid, dni, nss):
        self.__name = name
        self.__surnames = surnames
        self.__age = age
        self.__nid = nid
        self.__dni = dni
        self.__nss = nss
    # SHOW ALL CODES
    def getCodes(self):
        return "NID: " + str(self.__nid) + ", DNI: " + self.__dni+ ", NSS: " + self.__nss
    # RETURNS GENERAL INFORMATION
    def generalInfo(self):
        return "Name: "+self.__name+", surnames: "+self.__surnames+", age: "+str(self.__age)+". "+Associated.getCodes(self)
    # TO PRINT
    def showList(self):
        print("Associated name:"+self.__name+", surnames: "+self.__surnames +", N.I.D.: "+str(self.__nid)+", DNI: "+self.__dni+", NSS: "+self.__nss+".")
