# import requests
# test = requests.get("http://hipstercode.com")
# print(test)
# outfile = open("C:/Users/A735843/Desktop/cosa/test.txt","w")
# outfile.write("test.txt")


string = "hola como, estas"
if string.find(","):
    print("hola")