import json

from src.Artist import Artist


def parser_to_json(raw_list):
    artist_list_ready_to_json = []
    for i in range(len(raw_list)):
        if i % 2 == 0:
            a = Artist(raw_list[i], raw_list[i + 1])
            artist_list_ready_to_json.append(a.__dict__)

    f = open("C:/Users/A735843/PycharmProjects/TestingThings/Artist.json", "a")
    json.dump(artist_list_ready_to_json, f)
    f.close()
