class Artist(object):
    def __init__(self, name, dates):
        self.name = name
        try:
            if dates != "":
                if dates.find(",") == -1:
                    self.country = dates
                    self.date = "unknown"
                else:
                    if len(dates.split(",")) == 3:
                        a, b, self.date = dates.split(",")
                        self.country = a + b

                    else:
                        self.country, self.date = dates.split(",")
            else:
                self.date = "unknown"
                self.country = "unknown"
        except ValueError:
            print("The parser went wrong with artist named --> " + self.name)

    def toString(self):
        print("name: " + self.name + " date: " + self.date + " country: " + self.country)
