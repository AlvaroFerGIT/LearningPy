import certifi
import urllib3
from bs4 import BeautifulSoup

from src.MyJsonParserAndWriter import parser_to_json

# Handles the connection + certification
http = urllib3.PoolManager(cert_reqs='CERT_REQUIRED', ca_certs=certifi.where())

pages = []
# Request Get !!!! There is more than 1 page to move
for i in range(1, 24):
    url = "https://web.archive.org/web/20161025170331/http://www.nga.gov:80/collection/anA" + str(i) + ".htm"
    pages.append(url)

for item in pages:
    page = http.request("GET", item)
    # Store all the data of the request
    soup = BeautifulSoup(page.data, "html.parser")

    # decompose() get rid of unwanted tags, a table called AlphaNav in this example
    artist_name_list = soup.find(class_="AlphaNav")
    artist_name_list.decompose()

    # getting the Body
    artist_name_list = soup.find(class_="BodyText")
    # should be more specific on this one, but there is only one table so -_-
    artist_name_list_items = artist_name_list.find_all("td")

    # Getting every item inside of the tr, and extracting only the text
    # Example 1, using get_text, its kinda bad using this
    list_raw = []
    for artist in artist_name_list_items:
        list_raw.append(artist.get_text())
    #   print(artist.get_text())
    # Example 2, using content to get a list data type
    # for artist in artist_name_list_items:
    #    artists = artist_name_list_items.content[0]
    #    print(artists)
    parser_to_json(list_raw)
